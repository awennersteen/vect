#include <stdio.h>
#define N 50 

int main(int argc, char *argv[]) {
   int tock[N];
   int i;
   int temp=3;
   long int sum;

   i=-1;
   while(temp > 0) { 
      if (i>=0) {
        tock[i]=temp;
      }
      scanf("%d",&temp);
      ++i;
   } 

   sum=0;
   for(i=0;i<N;++i) {
     sum+=tock[i];
   }

   printf("sum is %ld\n",sum);
   
   return(0);
}
