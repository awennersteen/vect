#include <stdio.h>
#define N 50 

int main(int argc, char *argv[]) {
   int tock[N];
   int i,j;
   int temp=3;
   long int sum;

   i=-1;
   while(temp > 0) { 
      if (i>=0) {
        tock[i]=temp;
      }
      scanf("%d",&temp);
      ++i;
   } 

   sum=0;
   for(j=0;j<i;++j) {
     sum+=tock[j];
   }

   printf("sum is %ld\n",sum);
   
   return(0);
}
