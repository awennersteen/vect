#include <mpi.h>
#include <math.h>
#include <stdio.h>

void main(int argc, char* argv[])
{
      double sdata[55];
      double rdata[55];
      int p, i, count, myid, n;
      MPI_Status status;

      MPI_Init(&argc, &argv);                /* starts MPI */
      MPI_Comm_rank(MPI_COMM_WORLD, &myid);  /* get current process id */
      MPI_Comm_size(MPI_COMM_WORLD, &p);     /* get number of processes */

      if (myid == 1) {
        for(i=0;i<50;++i) { sdata[i]=(double)i; }
      }

      if (myid == 0) {
        MPI_Send(sdata,50,MPI_DOUBLE,1,123,MPI_COMM_WORLD);
      } else {
        MPI_Recv(rdata,55,MPI_DOUBLE,0,MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        MPI_Get_count(&status, MPI_DOUBLE, &count);
        do_work(rdata, count);
      }
      MPI_Finalize();                       /* let MPI finish up ... */
}

do_work(double *rdata, int count)
{
  int i;
  double maximum;

  maximum=rdata[0];
  for (i=1;i<count;i++)  
  {
    if (rdata[i]>maximum) maximum=rdata[i];
  }
  printf("The maximum value is: %e\n",maximum);
}
