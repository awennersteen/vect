#include <stdio.h>


void foo(float* A, int n, int i) {
  printf("====> %d, %d, %f\n", i, n, A[i]);
}
