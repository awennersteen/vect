#include <stdio.h>

#define n 10

int main()
{
  int i;
  float A[n];

  for (i=0; i<n; i++) {
    A[i] = (float) i+1;
  }

  i = 2;
  foo(A, n);

  return 0;
}

